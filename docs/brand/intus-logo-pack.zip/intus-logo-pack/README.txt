INTUS LOGO PACK
Option B, the section cut. Chosen 11 Oct 2026.

The mark is a slash that is solid at its head and dissolves into halftone dots,
the same way the statue bust fades from solid red into characters and then dots.

WHAT IS IN HERE

  svg/        The master files. Use these whenever you can; they stay sharp at any size.
    intus-mark.svg              the mark in red, tight to the artwork, transparent
    intus-mark-ink.svg          the mark in ink (one colour, for light grounds)
    intus-mark-paper.svg        the mark in paper (one colour, for dark and red grounds)
    intus-lockup.svg            the mark with the INTUS wordmark, red and ink
    intus-lockup-reversed.svg   the same in paper, for dark and red grounds
    intus-app-icon.svg          paper mark on a full-bleed red square
  png/        The same, as pictures, for places that do not take SVG.
    intus-mark-256h / 512h / 1024h.png   transparent, named by height in pixels
    intus-mark-ink-512h.png, intus-mark-paper-512h.png
    intus-lockup-1200w / 2400w.png, intus-lockup-reversed-1200w / 2400w.png   transparent
    intus-app-icon-1024 / 512 / 192.png
  favicon/    favicon.ico (16, 32 and 48 px), favicon.svg, apple-touch-icon.png (180 px)
  social/     intus-link-preview-1200x630.png, the image shown when a link is shared

COLOURS

  Red    #A31621   the mark
  Paper  #E5ECE9   the page ground, and the mark on dark grounds
  Ink    #1F1300   the wordmark, and the one-colour mark
  Dot    #A3988F   the background dot grid

The wordmark is INTUS in JetBrains Mono Medium, capitals, letter-spaced 0.12em.
In the SVG files it is drawn as outlines, so no font is needed.

USING IT

  - Red mark on paper or white. Paper mark on ink or red. Ink mark when only one colour is available.
  - Keep clear space around the mark of at least half its width.
  - Tested down to 16 px tall in the favicon tile and 28 px tall in the app header. At those sizes the
    dots blend into a soft fade, which is intended.
  - The favicon is the paper mark on a red tile because a bare red mark disappears on a dark browser tab.
  - App icons are full-bleed squares. iOS and Android apply their own corner mask, so do not round them.
  - Do not recolour, stretch, rotate, outline or add shadows. Do not change the dot spacing.
  - Miro's design system keeps red for the one main action on a screen. Use the ink mark where a red
    mark would compete with a red button.

IN THE WEBSITE

  <link rel="icon" href="/favicon.ico" sizes="48x48">
  <link rel="icon" href="/favicon.svg" type="image/svg+xml" sizes="any">
  <link rel="apple-touch-icon" href="/apple-touch-icon.png">
  <meta property="og:image" content="https://intus.fit/og.png">

NOT YET DONE

  No app store, trademark or look-alike check has been run on this logo.

SOURCE

  github.com/yuvrxxj/Intus, in docs/brand/logos (the three options) and scripts/brand_assets.py.
